#!/usr/bin/env python3
"""Matched CPU/GPU diagnostic fixtures; no throughput extrapolation."""
import datetime
import hashlib
import json
import statistics
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CRATE = REPO / "lattica-prover-p3"
GPU = "GPU-9ccf62bc-bc19-a667-4803-d3bce901ee6b"
OTHER_GPU = "GPU-b28db334-b11d-c7ec-1e24-d2f408b0a55c"
BINARY = ROOT / "gpu-tests"
ORIGINAL_RECORD = REPO / "docs/evidence/gpu-progress-benchmark-2026-10-08.json"
ORIGINAL = json.loads(ORIGINAL_RECORD.read_text())
TEMPLATES = {r["case"]: r["settings"] for r in ORIGINAL["runs"]}
FIXTURES = {
    "equality": (128, 3, "block_v2::machine::backend::gpu_registered_tests::matched_diagnostic_equality_proofs"),
    "empty": (2048, 2, "block_v2::statements::tests::matched_diagnostic_empty_proofs"),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    return subprocess.check_output([
        "nvidia-smi", "--id=" + GPU,
        "--query-gpu=uuid,name,driver_version,memory.total,memory.used,utilization.gpu,pstate,temperature.gpu",
        "--format=csv,noheader",
    ], text=True).strip()


def save():
    temporary = ROOT / "results.json.tmp"
    temporary.write_text(json.dumps(results, indent=2) + "\n")
    temporary.replace(ROOT / "results.json")


assert not (ROOT / "results.json").exists()
source = json.loads((ROOT / "source-manifest.json").read_text())
for name, digest in source["source_files"].items():
    assert sha(ROOT / "source" / name) == digest, name
assert source["proving_implementation_unchanged"]
results = {
    "schema_version": 1,
    "status": "running",
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "original_gpu_record": str(ORIGINAL_RECORD.relative_to(REPO)),
    "original_gpu_record_sha256": sha(ORIGINAL_RECORD),
    "source_head": source["head"],
    "original_source_captured_utc": source["original_snapshot_captured_utc"],
    "source_snapshot_sha256": sha(ROOT / "source.tar.gz"),
    "binary_sha256": sha(BINARY),
    "runner_sha256": sha(Path(__file__)),
    "measurement_wrapper_sha256": sha(ROOT / "measure-process.py"),
    "gpu_uuid": GPU,
    "gpu_before": snapshot(),
    "cpu": "Intel Core Ultra 9 275HX",
    "rayon_threads": 4,
    "service_limits": {"ram_bytes": 3 << 30, "swap_bytes": 0, "cpu_quota_percent": 400, "runtime_seconds": 180},
    "protocol_parameters_unchanged": True,
    "proving_implementation_unchanged": True,
    "scope": "128-row equality AIR and 2048-row twelve-key empty recursion; zero user transactions.",
    "timing_scope": "Successful block_v2_registered_program elapsed_ns measures witness generation and the prover call. Process timings include initialization, registration, independent CPU reference work, serialization and verification.",
    "design": "Same binary, circuits, public inputs, four Rayon threads and service limits. CPU uses cpu-required policy with all GPU flags disabled. GPU uses compatible policy with all supported prototype paths selected. Each fixture/arm has one warm-up and five measured process runs, with rotating backend order.",
    "limitations": [
        "Small diagnostic fixtures; no wallet proving, transaction-bearing recursion, or delivered throughput measurement.",
        "Strict GPU-only stage coverage remains incomplete.",
        "No CPU/GPU claim for larger workloads or the historical 64-input run.",
        "Proof randomness is fresh on every proof. No attempt is made to match random grinding effort.",
        "A new process does not imply a cold driver cache; compilation is excluded.",
        "Stage timings overlap and are not an additive wall-time breakdown.",
        "Peak RSS is child-process accounting; physical GPU memory peaks are not sampled.",
    ],
    "runs": [],
}
identities = {}
statements = {}
save()
arms = ["cpu", "gpu-full", "gpu-compact"]
for repetition in range(6):
    fixture_order = list(FIXTURES) if repetition % 2 == 0 else list(reversed(FIXTURES))
    for fixture in fixture_order:
        rows, expected_proofs, test_name = FIXTURES[fixture]
        offset = repetition % len(arms)
        order = arms[offset:] + arms[:offset]
        for arm in order:
            label = f"{fixture}-{arm}-r{repetition}"
            unit = "lattica-cpu-gpu-compare-20261008-r1-" + label
            prefix = "registered" if fixture == "equality" else "empty"
            template = prefix + ("-compact" if arm == "gpu-compact" else "-full")
            settings = dict(TEMPLATES[template])
            if arm == "cpu":
                settings = {k: ("0" if k.startswith("LATTICA_V2_GPU_") or k == "LATTICA_V2_QUOTIENT_FUSION" else v)
                            for k, v in settings.items()}
                settings["LATTICA_PROVING_POLICY"] = "cpu-required"
            settings["LATTICA_DIAGNOSTIC_GPU"] = "0" if arm == "cpu" else "1"
            log_path = ROOT / (label + ".log")
            resource_path = ROOT / (label + ".resources.json")
            command = ["systemd-run", "--user", "--quiet", "--wait", "--pipe", "--collect",
                       "--unit=" + unit, "--working-directory=" + str(CRATE)]
            command += ["--property=" + value for value in (
                "MemoryMax=3G", "MemorySwapMax=0", "CPUQuota=400%", "RuntimeMaxSec=180",
                "KillMode=control-group", "LimitCORE=0")]
            command += [f"--setenv={key}={value}" for key, value in settings.items()]
            command += [sys.executable, str(ROOT / "measure-process.py"), str(resource_path), str(BINARY),
                        test_name, "--exact", "--ignored", "--nocapture", "--test-threads=1"]
            assert sha(BINARY) == results["binary_sha256"]
            started = time.monotonic()
            try:
                with log_path.open("xb") as log:
                    completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=195)
                returncode = completed.returncode
            except subprocess.TimeoutExpired:
                subprocess.run(["systemctl", "--user", "stop", unit], check=False)
                returncode = 124
            process_seconds = time.monotonic() - started
            raw = log_path.read_text()
            def parsed(prefix):
                return [json.loads(line.split(prefix, 1)[1]) for line in raw.splitlines() if prefix in line]
            reports = parsed("proving_stage_report ")
            proofs = [r for r in reports if r["entry_point"] == "block_v2_registered_program" and r["succeeded"]]
            fixture_reports = parsed("matched_fixture ")
            proof_details = parsed("matched_proof ")
            success = (returncode == 0 and len(proofs) == expected_proofs
                       and len(fixture_reports) == 1 and len(proof_details) == expected_proofs
                       and "test result: ok. 1 passed; 0 failed;" in raw
                       and f"matched_verification fixture={fixture} cpu_verified={expected_proofs}" in raw
                       and all(r.get("observation_errors", 0) == 0 for r in proofs)
                       and OTHER_GPU not in raw)
            if arm == "cpu":
                success = (success and all(r["policy"] == "cpu_required" for r in proofs)
                           and all(o["backend"] == "cpu" for r in proofs for o in r["observations"])
                           and "bounded_gpu_" not in raw)
            else:
                success = (success and "RTX 5080 Laptop GPU" in raw
                           and "bounded_gpu_shutdown managed_live_bytes=0 lease_released=true" in raw
                           and "gpu_shutdown_before_audit=true" in raw)
            if fixture_reports:
                identity = {k: v for k, v in fixture_reports[0].items() if k not in ("registration_ns", "gpu_selected")}
                identities.setdefault(fixture, identity)
                success = success and identity == identities[fixture]
                public = [{k: v for k, v in d.items() if k != "bytes"} for d in proof_details]
                statements.setdefault(fixture, public)
                success = success and public == statements[fixture]
            resources = json.loads(resource_path.read_text()) if resource_path.exists() else None
            run = {"label": label, "fixture": fixture, "arm": arm, "repetition": repetition,
                   "warmup": repetition == 0, "rows": rows, "success": success, "returncode": returncode,
                   "process_seconds": process_seconds, "resources": resources, "command": command,
                   "settings": settings, "fixture_reports": fixture_reports, "proof_details": proof_details,
                   "proof_seconds": [r["elapsed_ns"] / 1e9 for r in proofs], "proof_reports": proofs,
                   "other_reports": [r for r in reports if r not in proofs], "log_sha256": sha(log_path)}
            results["runs"].append(run)
            save()
            print(json.dumps({k: run[k] for k in ("label", "success", "process_seconds", "proof_seconds")}), flush=True)
            if not success:
                results["status"] = "failed"
                results["gpu_after"] = snapshot()
                save()
                raise SystemExit(1)

results["summaries"] = []
for fixture in FIXTURES:
    for arm in arms:
        runs = [r for r in results["runs"] if r["fixture"] == fixture and r["arm"] == arm and not r["warmup"]]
        durations = [x for r in runs for x in r["proof_seconds"]]
        processes = [r["process_seconds"] for r in runs]
        results["summaries"].append({
            "fixture": fixture, "arm": arm, "measured_processes": len(runs), "measured_proofs": len(durations),
            "proof_seconds": {"minimum": min(durations), "median": statistics.median(durations), "maximum": max(durations)},
            "process_seconds": {"minimum": min(processes), "median": statistics.median(processes), "maximum": max(processes)},
            "max_process_rss_kib": max(r["resources"]["max_rss_kib"] for r in runs),
        })
results["comparisons"] = []
for fixture in FIXTURES:
    summaries = {s["arm"]: s for s in results["summaries"] if s["fixture"] == fixture}
    cpu = summaries["cpu"]["proof_seconds"]["median"]
    for arm in arms[1:]:
        gpu = summaries[arm]["proof_seconds"]["median"]
        pairs = []
        for repetition in range(1, 6):
            runs = {r["arm"]: r for r in results["runs"] if r["fixture"] == fixture and r["repetition"] == repetition}
            pairs.append(sum(runs[arm]["proof_seconds"]) / sum(runs["cpu"]["proof_seconds"]))
        results["comparisons"].append({"fixture": fixture, "gpu_arm": arm,
            "gpu_over_cpu_median_proof_time": gpu / cpu,
            "cpu_over_gpu_median_proof_time": cpu / gpu,
            "per_round_gpu_over_cpu_proving_sum": pairs,
            "median_paired_gpu_over_cpu_proving_sum": statistics.median(pairs)})
results["fixture_identities"] = identities
results["public_statements"] = statements
results["gpu_after"] = snapshot()
results["status"] = "passed"
results["completed_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({"status": results["status"], "summaries": results["summaries"], "comparisons": results["comparisons"]}), flush=True)
