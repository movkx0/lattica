#!/usr/bin/env python3
"""Account for one child process using the standard library."""
import json
import resource
import subprocess
import sys
import time
from pathlib import Path

started = time.monotonic()
completed = subprocess.run(sys.argv[2:])
elapsed = time.monotonic() - started
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
Path(sys.argv[1]).write_text(json.dumps({
    "wall_seconds": elapsed,
    "user_seconds": usage.ru_utime,
    "system_seconds": usage.ru_stime,
    "max_rss_kib": usage.ru_maxrss,
    "exit_status": completed.returncode,
}) + "\n")
raise SystemExit(completed.returncode if completed.returncode >= 0 else 128 - completed.returncode)
