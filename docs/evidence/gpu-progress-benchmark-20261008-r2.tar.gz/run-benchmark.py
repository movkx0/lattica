#!/usr/bin/env python3
"""Bounded diagnostic measurements of an immutable in-progress GPU build."""
import datetime
import hashlib
import json
import re
import shutil
import statistics
import subprocess
import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CRATE = ROOT.parent.parent
GPU = "GPU-9ccf62bc-bc19-a667-4803-d3bce901ee6b"
OTHER_GPU = "GPU-b28db334-b11d-c7ec-1e24-d2f408b0a55c"
REFERENCE = CRATE / "benchmark-results/gpu-setup-quotient-20261008/run-01/manifest.json"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gpu_snapshot():
    return subprocess.check_output([
        "nvidia-smi", "--id=" + GPU,
        "--query-gpu=uuid,name,driver_version,memory.total,memory.used,utilization.gpu,pstate,temperature.gpu",
        "--format=csv,noheader",
    ], text=True).strip()


def save():
    temp = ROOT / "results.json.tmp"
    temp.write_text(json.dumps(results, indent=2) + "\n")
    temp.replace(ROOT / "results.json")


source = json.loads((ROOT / "source-manifest.json").read_text())
assert not source["changed_during_capture"]
for name, expected in source["source_files"].items():
    assert digest(ROOT / "source" / name) == expected, name
build = [json.loads(line) for line in (ROOT / "build.jsonl").read_text().splitlines()]
assert any(r.get("reason") == "build-finished" and r.get("success") for r in build)
executables = [r["executable"] for r in build if r.get("reason") == "compiler-artifact"
               and r.get("executable") and r["target"]["name"] == "lattica_prover_p3"]
assert len(executables) == 1, executables
binary = ROOT / "gpu-tests"
previous_attempt = json.loads((ROOT.with_name("gpu-progress-benchmark-20261008-r1") / "results.json").read_text())
assert digest(binary) == previous_attempt["binary_sha256"]
templates = {r["name"]: r for r in json.loads(REFERENCE.read_text())["tests"]}
cases = [
    ("registered-full", "registered-transcript-full", 128, 3),
    ("registered-compact", "registered-transcript-compact", 128, 3),
    ("empty-full", "twelve_key-full", 2048, 2),
    ("empty-compact", "twelve_key-compact", 2048, 2),
]
results = {
    "schema_version": 1,
    "status": "running",
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_head": source["head"],
    "previous_launch": {"path": str(ROOT.with_name("gpu-progress-benchmark-20261008-r1")), "status": "failed before proving", "reason": "optional /usr/bin/time utility unavailable"},
    "source_snapshot_sha256": digest(ROOT / "source.tar.gz"),
    "source_manifest_sha256": digest(ROOT / "source-manifest.json"),
    "binary_sha256": digest(binary),
    "runner_sha256": digest(Path(__file__)),
    "build_profile": "release, thin LTO, x86-64-v3",
    "features": ["default (gpu)", "block-v2-wide-lanes"],
    "gpu_uuid": GPU,
    "gpu_before": gpu_snapshot(),
    "cpu": "Intel Core Ultra 9 275HX",
    "rayon_threads": 4,
    "service_limits": {"ram_bytes": 3 << 30, "swap_bytes": 0,
                       "cpu_quota_percent": 400, "runtime_seconds": 180},
    "scope": "Diagnostic registered equality AIR (128 rows) and twelve-key empty recursive proofs (2048 rows). No user transactions or wallet proving.",
    "timing_scope": "Proof elapsed_ns comes from each successful block_v2_registered_program report: witness generation plus prover invocation. Registration, test CPU reference work, verification, process launch and setup are excluded. Process timings include those costs and correctness checks.",
    "limitations": [
        "Strict GPU-only policy is not selected; compatible policy enables all supported GPU path flags.",
        "No transactions/minute estimate and no comparison to historical full-size timings.",
        "GPU cache may already be warm; a new process does not imply a cold driver cache.",
        "Stage wall spans overlap. Device events do not form an additive wall-time breakdown.",
        "Managed allocator watermarks do not measure physical VRAM peaks.",
        "One warm-up process and three measured processes per case; results are exploratory.",
    ],
    "runs": [],
}
save()
for repetition in range(4):
    ordered = cases if repetition % 2 == 0 else list(reversed(cases))
    for name, template, rows, proof_count in ordered:
        label = f"{name}-r{repetition}"
        unit = "lattica-gpu-progress-20261008-r2-" + label
        log_path = ROOT / (label + ".log")
        resource_path = ROOT / (label + ".resources.json")
        command = templates[template]["command"].copy()
        executable_index = next(i for i, arg in enumerate(command) if arg.endswith("/gpu-tests"))
        command = ["--unit=" + unit if arg.startswith("--unit=") else arg for arg in command]
        command[executable_index:executable_index + 1] = [
            sys.executable, str(ROOT / "measure-process.py"), str(resource_path), str(binary),
        ]
        assert "--setenv=LATTICA_GPU_DEVICE_UUID=" + GPU in command
        assert not any(OTHER_GPU in arg for arg in command)
        assert digest(binary) == results["binary_sha256"]
        started = time.monotonic()
        try:
            with log_path.open("xb") as log:
                completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=195)
            returncode = completed.returncode
        except subprocess.TimeoutExpired:
            subprocess.run(["systemctl", "--user", "stop", unit], check=False)
            returncode = 124
        process_seconds = time.monotonic() - started
        raw = log_path.read_text()
        reports = [json.loads(line.split("proving_stage_report ", 1)[1])
                   for line in raw.splitlines() if "proving_stage_report " in line]
        proofs = [r for r in reports if r["entry_point"] == "block_v2_registered_program" and r["succeeded"]]
        success = (returncode == 0 and len(proofs) == proof_count
                   and "test result: ok. 1 passed; 0 failed;" in raw
                   and "bounded_gpu_shutdown managed_live_bytes=0 lease_released=true" in raw
                   and "RTX 5080 Laptop GPU" in raw and OTHER_GPU not in raw
                   and all(r.get("observation_errors", 0) == 0 for r in proofs))
        resources = None
        if resource_path.exists():
            resources = next((json.loads(line) for line in resource_path.read_text().splitlines()
                              if line.startswith("{")), None)
        settings = dict(arg.removeprefix("--setenv=").split("=", 1)
                        for arg in command if arg.startswith("--setenv="))
        run = {"label": label, "case": name, "warmup": repetition == 0, "rows": rows,
               "success": success, "returncode": returncode, "command": command,
               "settings": settings, "process_seconds": process_seconds, "resources": resources,
               "proof_seconds": [r["elapsed_ns"] / 1e9 for r in proofs],
               "proof_reports": proofs, "other_reports": [r for r in reports if r not in proofs],
               "log_sha256": digest(log_path), "verification": "Original CPU verifier after GPU shutdown; altered public statements also rejected" if success else "not qualified",
               "managed_peak_bytes": [int(x) for x in re.findall(r"(?<![a-z_])managed_peak_bytes=(\d+)", raw)]}
        results["runs"].append(run)
        save()
        print(json.dumps({k: run[k] for k in ("label", "success", "process_seconds", "proof_seconds")}), flush=True)
        if not success:
            results["status"] = "failed"
            results["gpu_after"] = gpu_snapshot()
            save()
            raise SystemExit(1)
results["summaries"] = []
for name, _, rows, count in cases:
    runs = [r for r in results["runs"] if r["case"] == name and not r["warmup"]]
    durations = [x for r in runs for x in r["proof_seconds"]]
    process = [r["process_seconds"] for r in runs]
    results["summaries"].append({
        "case": name, "rows": rows, "measured_processes": len(runs), "measured_proofs": len(durations),
        "proof_seconds": {"minimum": min(durations), "median": statistics.median(durations), "maximum": max(durations)},
        "process_seconds": {"minimum": min(process), "median": statistics.median(process), "maximum": max(process)},
        "max_process_rss_kib": max(r["resources"]["max_rss_kib"] for r in runs),
    })
results["status"] = "passed"
results["gpu_after"] = gpu_snapshot()
results["completed_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({"status": results["status"], "summaries": results["summaries"]}), flush=True)
